import { STRING_TYPE } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import TaskModel from 'src/app/models/task';
import Priority from 'src/app/models/taskPriority';
import Status from 'src/app/models/taskStatus';
import { AuthService } from 'src/app/services/auth.service';
import { TodoService } from 'src/app/services/todo.service';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {
  CreateForm!:FormGroup;
  priorityOptions: Priority[] = [Priority.Low, Priority.Medium, Priority.High];
  statusOptions: Status[] = [Status.Pending, Status.InProgress, Status.Done, Status.Canceled];
constructor(private todoService: TodoService,private router:Router,private fb: FormBuilder,private auth:AuthService){
  
}
  ngOnInit(): void {
    this.CreateForm = this.fb.group({
      title: [''],
      description: ['', Validators.required],
      priority: [0, Validators.required],
      status: [0, Validators.required],
      deadline: [null]
    });
  }
 



 onSubmit() {
  if (this.CreateForm.valid) {
    const currentDate = new Date();
    const deadlineDate = new Date(this.CreateForm.value.deadline);
    const taskData: TaskModel = {
      id:0,
      title: this.CreateForm.value.title,
      description: this.CreateForm.value.description,
      priority:+this.CreateForm.value.priority,
      status: +this.CreateForm.value.status,
      createdAt: currentDate.toISOString(),
      deadline: this.CreateForm.value.deadline ? new Date(this.CreateForm.value.deadline).toISOString() : null,
      assignedUserId:" "
    };
    this.todoService.createTask(taskData)
    .subscribe(res=>{
      console.log('Task added',taskData,res);
      this.router.navigate(['todo']);
    },
    error=>{
      console.log(error.err)
    }
    )
  }
}
getPriorityString(priority: Priority): string {
  return Priority[priority];
}

getStatusString(status: Status): string {
  return Status[status];
}
}
