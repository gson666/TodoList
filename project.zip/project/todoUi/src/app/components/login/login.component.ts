import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgToastService } from 'ng-angular-popup';
import { AuthService } from 'src/app/services/auth.service';
import { UserstoreService } from 'src/app/services/userstore.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  type:string = "password";
  isText:boolean =false;
  eyeIcon :string = "fa-eye-slash";
  loginForm!:FormGroup;

  constructor(private fb: FormBuilder,private auth:AuthService,private router:Router,private toast:NgToastService,private userStored:UserstoreService){}

  ngOnInit():void{
    this.loginForm = this.fb.group({
      username:['',Validators.required],
      password:['',Validators.required]
    })
  }

  hideShowPass(){
    this.isText = !this.isText;
    this.isText?this.eyeIcon = "fa-eye" : this.eyeIcon = "fa-eye-slash";
    this.isText?this.type = "text" : this.type = "password";
  }
  onLogin(){
    if(this.loginForm.valid){
      this.auth.login(this.loginForm.value)
      .subscribe({
        next:(res=>{
          console.log(res.message);
          this.loginForm.reset();
          this.auth.storeToken(res.token);
           let tokenPayLoad = this.auth.decodedToken();
           console.log(tokenPayLoad);
           this.userStored.setFullNameForStore(tokenPayLoad.name);
          this.toast.success({detail:"SUCCESS",summary:res.message,duration:10000});
          this.router.navigate(['todo']);
        }),
        error:(err)=>{
          console.log(err?.error.message);
        }
      })
    }
  }
}
