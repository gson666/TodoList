import { Component, EventEmitter, Input, NgZone, OnInit,Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { NgToastModule } from 'ng-angular-popup';
import { Toast } from 'ngx-toastr';

import LoginDto from 'src/app/models/LoginDto';
import TaskModel from 'src/app/models/task';
import Priority from 'src/app/models/taskPriority';
import Status from 'src/app/models/taskStatus';
import { ApiService } from 'src/app/services/api.service';
import { AuthService } from 'src/app/services/auth.service';
import { TodoService } from 'src/app/services/todo.service';
import { UserstoreService } from 'src/app/services/userstore.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
Priority: any;
Status: any;
priorityOptions: Priority[] = [Priority.Low, Priority.Medium, Priority.High];
statusOptions: Status[] = [Status.Pending, Status.InProgress, Status.Done, Status.Canceled];
updateForm!:FormGroup;
selectedFilter: string = 'all'
  constructor(private formBuilder: FormBuilder,private auth:AuthService,private api:ApiService,private storedUser:UserstoreService ,private todoService:TodoService,private router:Router){}
  ngOnInit(): void {
    
      this.api.getUsers()
      .subscribe(res=>{
        this.users = res;
      })
      this.storedUser.getFullNameFromStore().subscribe((val) => {
        let fullNameFromToken = this.auth.decodedToken()['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name'];
        this.name = fullNameFromToken || val;
      })
      this.todoService.getUserTasks().subscribe(tasks => {
        console.log(tasks);
        this.tasks = tasks;
        this.filterTasks();
        
      });
      
    
  }
 
 public users:any = [];
 public name :string | null = "";
 tasks: TaskModel[] = [];
  filteredTasks: TaskModel[] = [];
 
  filterTasks(): void {
    switch (this.selectedFilter) {
      case 'closed':
        this.filteredTasks = this.tasks.filter(task => task.status === Status.Done || task.status === Status.Canceled);
        break;
      case 'open':
        this.filteredTasks = this.tasks.filter(task => task.status === Status.Pending || task.status === Status.InProgress);
        break;
      default:
        this.filteredTasks = this.tasks;
        break;
    }
  }
  
  
  
  

  getPriorityString(priority: Priority): string {
    return Priority[priority];
  }

  
  getStatusString(status: Status): string {
    return Status[status];
  }

 logout(){
  const confirmation = confirm('Do you want to logout?')
  if(confirmation){
    this.auth.logout();
  }
 }
 isTaskNearDeadline(deadline: string | null | undefined): boolean {
  if (!deadline) {
    return false;
  }
  const today = new Date();
  const taskDeadline = new Date(deadline);

  const deadlineWith7Days = new Date(taskDeadline.getTime());
  deadlineWith7Days.setDate(taskDeadline.getDate() - 7);

  return today > deadlineWith7Days;
}
 
 
deleteTask(taskId: number): void {
  const confirmation = confirm('Are You Sure?')
  if(confirmation){
    this.todoService.deleteTask(taskId).subscribe(
      (deletedTask) => {
        
        console.log('Task deleted successfully:', deletedTask);
        alert("Tasks deleted successfully!");
        this.router.navigate(['todo']);
        this.tasks = this.tasks.filter(task => task.id !== taskId);
      },
      (error) => {
        
        console.error('Error deleting task:', error);
      }
    );
  }
  
}

convertToDate(dateString: string): Date {
  return new Date(dateString);
}
isNoDeadline(deadline: string | null | undefined): boolean {
  return !deadline;
}
changeStatus(task: TaskModel): void {
  const updatedTask: TaskModel = { ...task, status: Status.Done }; 

  this.todoService.updateTask(task.id, updatedTask).subscribe(
    (result) => {
      console.log('Task status updated successfully:', result);

      const index = this.tasks.findIndex((t) => t.id === task.id);
      if (index !== -1) {
        this.tasks[index] = result;
      }
    },
    (error) => {
      console.error('Error updating task status:', error);
    }
  );
}





// getStatusString(status: number): string {
//   switch (status) {
//     case Status.Pending:
//       return 'Pending';
//     case Status.InProgress:
//       return 'In Progress';
//     case Status.Done:
//       return 'Done';
//     case Status.Canceled:
//       return 'Canceled';
//     default:
//       return '';
//   }
// }
// getPriorityString(priority: number): string {
//   switch (priority) {
//     case Priority.Low:
//       return 'Low';
//     case Priority.Medium:
//       return 'Medium';
//     case Priority.High:
//       return 'High';
//     default:
//       return '';
//   }
// }

}
