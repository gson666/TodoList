import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  type:string = "password";
  isText:boolean =false;
  eyeIcon :string = "fa-eye-slash";
  signUpForm!:FormGroup;

  constructor(private fb: FormBuilder,private auth:AuthService,private router:Router){}

  ngOnInit():void{
    this.signUpForm= this.fb.group({
      username:['',Validators.required],
      firstname:['',Validators.required],
      lastname:['',Validators.required],
      email:['',Validators.required],
      password:['',Validators.required]
    })
  }
  onSignup(){
    if(this.signUpForm.valid){
      this.auth.register(this.signUpForm.value)
      .subscribe({
        next:(res=>{
          console.log(res.message)
          this.signUpForm.reset();
          alert("Register successful!")
          this.router.navigate(['login']);
        }),
        error:(err=>{
          console.log(err.error.message)
        })
      })

    }

  }

  hideShowPass(){
    this.isText = !this.isText;
    this.isText?this.eyeIcon = "fa-eye" : this.eyeIcon = "fa-eye-slash";
    this.isText?this.type = "text" : this.type = "password";
  }

}
