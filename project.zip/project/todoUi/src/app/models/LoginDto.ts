  interface LoginDto {
    username: string;
    password: string;
  }
  export default LoginDto;