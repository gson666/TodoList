import Priority from "./taskPriority";
import Status from "./taskStatus";

class TaskModel {
    constructor(
      public id: number,
      public title: string,
      public description: string,
      public priority:number,
      public status:number,
      public createdAt:string,
      public deadline?: string|null,
      public assignedUserId: string = ''
    ) {}
  }
  export default TaskModel;