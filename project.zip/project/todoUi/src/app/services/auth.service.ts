import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import RegisterDto from '../models/RegisterDto';
import LoginDto from '../models/LoginDto';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';



@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:5216/api/Auth';
  private userLoad:any;


  constructor(private http: HttpClient,private router:Router) { 
    this.userLoad = this.decodedToken();
  }

  register(user: RegisterDto): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, user);
  }
  

  storeToken(tokenValue:string){
    localStorage.setItem('token',tokenValue);
  }
  getToken(): string | null {
    return localStorage.getItem('token');
  }

  isLoggedIn():boolean{
    return !!localStorage.getItem('token');
  }
  
 
  login(user:LoginDto):Observable<any>{
    return this.http.post<any>(`${this.apiUrl}/login`,user);
  }
  
decodedToken(){
  const jwtHelper = new JwtHelperService();
  const token = this.getToken()!;
  return jwtHelper.decodeToken(token);
}

  logout(): void {
    localStorage.clear();
    this.router.navigate(['login']);

  }

  getfullNameFromToken(){
    if(this.userLoad){
      return this.userLoad.name;
    }
  }
  getIdFromToken(): string | null {
    if (this.userLoad) {
      return this.userLoad.nameidentifier;
    }
    return null;
  }
}


