import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
private baseUrl:string = "http://localhost:5216/api/Auth";
  constructor(private http:HttpClient) { }

  getUsers(){
    return this.http.get<any>(`${this.baseUrl}/getAllUsers`);
  }

  getLoggedUser(){
    return this.http.get<any>(`${this.baseUrl}/getLoggedUser`);
  }
}
