import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http'
import TaskModel from '../models/task';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  private apiUrl = 'http://localhost:5216/api/Todo';
  constructor(private http: HttpClient,private auth:AuthService) { }

  getAllTasks(): Observable<TaskModel[]> {
    return this.http.get<TaskModel[]>(`${this.apiUrl}/allTasks`);
  }
   getUserTasks():Observable<TaskModel[]>{
     return this.http.get<TaskModel[]>(`${this.apiUrl}/userTasks`);
   }
  


  createTask(task: TaskModel): Observable<TaskModel> {
    
    return this.http.post<TaskModel>(`${this.apiUrl}/createTask`, task);
  }
  updateTask(taskId: number,task: TaskModel): Observable<TaskModel> {
    return this.http.put<TaskModel>(`${this.apiUrl}/edit/${taskId}`, task);
  }
  deleteTask(taskId: number): Observable<TaskModel> {
    return this.http.delete<TaskModel>(`${this.apiUrl}/delete/${taskId}`);
  }
  getTaskById(taskId:number): Observable<TaskModel>{
    return this.http.get<TaskModel>(`${this.apiUrl}/getTaskById/${taskId}`);
  }


}
