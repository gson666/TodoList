﻿namespace AnotherAPI.Models
{
    public enum StatusModel
    {
        Pending,
        InProgress,
        Done,
        Canceled
    }
}