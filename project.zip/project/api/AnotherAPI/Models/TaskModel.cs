﻿using AnotherAPI.Data;
using System.ComponentModel.DataAnnotations;

namespace AnotherAPI.Models
{
    public class TaskModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage ="Title is required")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; }
        public PriorityModel Priority { get; set; }
        public StatusModel Status { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime Deadline { get; set; }
        public string AssignedUserId { get; set; }
        

       
    }
}
