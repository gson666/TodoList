﻿namespace AnotherAPI.Models
{
    public enum PriorityModel
    {
        Low,
        Medium,
        High
    }
}