﻿using AnotherAPI.Data;
using AnotherAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AnotherAPI.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class TodoController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        public TodoController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [HttpGet("allTasks")]
        public async Task<IActionResult> GetTasks()
        {
            try
            {
                var tasks = await _context.Tasks.ToListAsync();
                return Ok(tasks);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpGet("userTasks")]
        public async Task<IActionResult> GetUserTasks()
        {
            try
            {
                var authenticatedUser = await _userManager.GetUserAsync(User);

                if (authenticatedUser == null)
                {
                    return Unauthorized(new { Message = "User not found" });
                }

                var userTasks = await _context.Tasks
                    .Where(task => task.AssignedUserId == authenticatedUser.Id)
                    .ToListAsync();

                return Ok(userTasks);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost("createTask")]
        public async Task<IActionResult> CreateTask([FromBody] TaskModel task)
        {
            try
            {
                var authenticatedUser = await _userManager.GetUserAsync(User);

                task.AssignedUserId = authenticatedUser.Id;

                task.CreatedAt = DateTime.Now;
                _context.Tasks.Add(task);
                await _context.SaveChangesAsync();
                return Ok(task);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut("edit/{id}")]
        public async Task<IActionResult> UpdateTask(int id, [FromBody] TaskModel updatedTask)
        {
            try
            {
                var existingTask = await _context.Tasks.FindAsync(id);

                if (existingTask == null)
                {
                    return NotFound();
                }

                existingTask.Title = updatedTask.Title;
                existingTask.Description = updatedTask.Description;
                existingTask.Priority = updatedTask.Priority;
                existingTask.Status = updatedTask.Status;
                existingTask.Deadline = updatedTask.Deadline;

                await _context.SaveChangesAsync();

                return Ok(existingTask);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteTask(int id)
        {
            try
            {
                var taskToDelete = await _context.Tasks.FindAsync(id);

                if (taskToDelete == null)
                {
                    return NotFound();
                }

                _context.Tasks.Remove(taskToDelete);
                await _context.SaveChangesAsync();

                return Ok(taskToDelete);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
